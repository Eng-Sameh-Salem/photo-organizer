
# Photo Organizer (Standalone Python Script)

منظّم صور بسيط واحترافي يعتمد على بايثون. يقوم بترتيب صورك داخل مجلدات `سنة/شهر` اعتماداً على تاريخ الالتقاط من EXIF (وعند عدم توفره يستخدم وقت آخر تعديل للملف).

## الميزات
- قراءة EXIF (`DateTimeOriginal`, `DateTimeDigitized`, `DateTime`).
- إنشاء مجلدات تلقائياً حسب السنة/الشهر.
- نمط تسمية مرن عبر `--pattern` (افتراضياً: `{Y}/{m}/{Y}-{m}-{d}_{name}{ext}`).
- وضع **Dry Run** للمعاينة قبل التنفيذ.
- **نسخ** أو **نقل** الملفات (اختيارياً).
- مسح **递归/Recursive** للمجلدات.
- إنشاء **تقرير CSV** لنتائج التشغيل.
- منع تكرار الملفات عبر فحص تجزئة SHA-256 (`--dedupe`).
- تجنّب الكتابة فوق الملفات عبر إعادة تسمية ذكية.
- دعم HEIC/HEIF (اختياري بتثبيت `pillow-heif`).

## التثبيت السريع
```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows
# .venv\Scripts\activate

pip install -r requirements.txt
# لدعم HEIC/HEIF (اختياري):
# pip install pillow-heif
```

## أمثلة تشغيل
```bash
# معاينة بدون كتابة (Dry Run)
python organize_photos.py --src ~/Downloads --dst ~/Organized --dry-run

# نسخ الملفات مع المسح递归
python organize_photos.py --src ./inbox --dst ./Photos --copy --recursive

# نقل الملفات بدلاً من النسخ + تقرير CSV
python organize_photos.py --src ./inbox --dst ./Photos --move --report ./report.csv

# تخصيص النمط (يقبل {Y},{m},{d},{H},{M},{S},{name},{ext})
python organize_photos.py --src ./inbox --dst ./Photos --pattern "{Y}/{m}/{Y}-{m}-{d}_{name}{ext}"
```

## ملاحظات
- الإضافات المدعومة افتراضياً: `.jpg,.jpeg,.png,.tif,.tiff,.bmp,.gif,.webp,.heic,.heif`
  (لـ HEIC/HEIF تحتاج تثبيت `pillow-heif`).
- إذا لم تتوفر EXIF، سيتم استخدام وقت آخر تعديل للملف.
- لتقليل المخاطر، ابدأ دائماً بـ `--dry-run` قبل التنفيذ الحقيقي.

## الترخيص
MIT
